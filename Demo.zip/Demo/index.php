<?php
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- https://ajax.googleapis.com/ajax/libs/jquery/3.3.1 -->
  <script src="vendor/jquery/jquery.min.js"></script>

  <!-- https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js -->
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
</head>
<body>


<div class="container-fluid"  >

  <div class="row">
    <div class="col-sm-2" style="background-color:#2d1606 ;height:70px;width:254px">Side Bar</div>
    <div class="col-sm-10" style="background-color:white;padding:15px;height:70px;">
<!--  -->
<div class="row">
<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">


  <nav class="navbar navbar-expand-sm bg-light">
    <div class="col-sm-8">


                      <div class="row">
                      <div class="col-sm-7">
                        #General
                          <!-- <ul class="navbar-nav">
                          <li class="nav-item">
                          <a class="nav-link" href="#">#general</a>
                          </li>
                          </ul> -->
                      </div>
                      <div class="col-sm-7">* | U1 | P6 | Add a topic</div>
                     <div class="col-sm-5"></div>
                    </div>
                  </div>
  <div class="col-sm-4">

              <div class="row">
                <div class="col-sm-1 " style="position:relative">
                <label><img src="call.png" width="18" height="18"/></label>
                </div>
                <div class="col-sm-1">
                      <label><img src="info.png" width="18" height="18"/></label>
                </div>
                <div class="col-sm-1">
                    <label><img src="setting.png" width="18" height="18"/></label>
                </div>
                  <div class="col-sm-6 ">
                    <!-- <form class="form-inline "> -->
                    <!-- <input id="searchstring" type="text" oninput="" placeholder="Search.." name="search"> -->
                     <input class="form-control" type="text" oninput="" placeholder="Search">
                    <!-- </form> -->
                  </div>
                              <div class="col-sm-1">
                                <label height="20 "width="20">@</label>
                              </div>
                              <div class="col-sm-1">
                                <label><img src="star.svg" width="18" height="18"/></label>
                              </div>
                              <div class="col-sm-1">
                                <label><img src="option.png" width="18" height="18"/></label>
                              </div>
              </div>
    </div>
  </div>
</nav>
</div>



<!--  -->
    </div>
  </div>


  <div class="row" style=" " >
    <div class="col-sm-2" id="sidebar" style="background-color:#2d1606; height:600px;"></div>
    <div class="col-sm-8" style="background-color:lavenderblush;height:600px;">Main Body</div>
    <div class="col-sm-2" style="background-color:#2d1606;height:600px;">Extra body</div>
  </div>

  <div class="row">
    <div class="col-sm-2" id="sidebar" style="background-color:#2d1606;height:70px;"></div>
    <div class="col-sm-10" style="background-color:lavender;height:70px;">footer</div>
  </div>

</div>


</body>
</html>

<?php
?>
